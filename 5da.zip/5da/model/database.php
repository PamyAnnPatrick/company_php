<?php
    $dsn = 'mysql:host=localhost;dbname=company';
    $username = 'mgs_user';
    $password = 'pwd';

    try {
        $db = new PDO($dsn, $username, $password);  // MAKING A NEW OBJECT OF THE PDO TYPE
    } catch (PDOException $e) {
        $error_message = $e->getMessage();
        include('../errors/database_error.php');
        exit();
    }
?>