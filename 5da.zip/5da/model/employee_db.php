<?php
function get_employees() {
    global $db;
    $query = 'SELECT empID,empCode,empName,empSalary,d.deptName
     FROM emps e
      inner join depts d on d.deptID=e.deptID
       order by empID';
    $statement = $db->prepare($query);
    $statement->execute();
    return $statement;
}
function get_employees_id($employee_id) {
    global $db;
    $query = 'SELECT empID,empCode,empName,empSalary,d.deptName,d.deptID
     FROM emps e
      inner join depts d on d.deptID=e.deptID
       where empID=:employee_id';
    $statement = $db->prepare($query);
    $statement->bindValue(':employee_id', $employee_id);
    $statement->execute();
    $employee = $statement->fetch();
    return $employee;
}
function delete_employee($employee_id) {
    global $db;
    $query = 'DELETE FROM emps
              WHERE empID = :employee_id';
    $statement = $db->prepare($query);
    $statement->bindValue(':employee_id', $employee_id);
    $statement->execute();
    $statement->closeCursor();
}
function add_employee($dept_id, $emp_code, $emp_name, $emp_salary) {
    global $db;
    $query = 'INSERT INTO emps
                 (deptID, empCode, empName, empSalary)
              VALUES
                 (:dept_id, :emp_code, :emp_name, :emp_salary)';
    $statement = $db->prepare($query);
    $statement->bindValue(':dept_id', $dept_id);
    $statement->bindValue(':emp_code', $emp_code);
    $statement->bindValue(':emp_name', $emp_name);
    $statement->bindValue(':emp_salary', $emp_salary);
    $statement->execute();
    $statement->closeCursor();
}
function update_employee($dept_id, $emp_code, $emp_name, $emp_salary,$emp_id) {
    global $db;
    $query = 'update emps set deptID=:dept_id, empCode=:emp_code,
                       empName=:emp_name, empSalary=:emp_salary where empID=:emp_id';
    $statement = $db->prepare($query);
    $statement->bindValue(':dept_id', $dept_id);
    $statement->bindValue(':emp_code', $emp_code);
    $statement->bindValue(':emp_name', $emp_name);
    $statement->bindValue(':emp_salary', $emp_salary);
    $statement->bindValue(':emp_id', $emp_id);
    $statement->execute();
    $statement->closeCursor();
}

?>