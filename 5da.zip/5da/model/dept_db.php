<?php
function get_departments() {
    global $db;
    $query = 'SELECT * FROM depts
              ORDER BY deptID';
    $statement = $db->prepare($query);
    $statement->execute();
    return $statement;
}
function delete_dept($dept_id) {
    global $db;
    $query = 'DELETE FROM emps
              WHERE deptID = :dept_id;
              DELETE FROM depts
              WHERE deptID = :dept_id';
    $statement = $db->prepare($query);
    $statement->bindValue(':dept_id', $dept_id);
    $statement->execute();
    $statement->closeCursor();
}
function add_department($dept_name) {
    global $db;
    $query = 'INSERT INTO depts
                 (deptName)
              VALUES
                 (:dept_name)';
    $statement = $db->prepare($query);
    $statement->bindValue(':dept_name', $dept_name);
    $statement->execute();
    $statement->closeCursor();
}
function update_department($dept_name,$dept_id) {
    global $db;
    $query = 'update depts set deptName=:dept_name where deptID=:dept_id';
    $statement = $db->prepare($query);
    $statement->bindValue(':dept_name', $dept_name);
    $statement->bindValue(':dept_id', $dept_id);
    $statement->execute();
    $statement->closeCursor();
}
function get_department($dept_id) {
    global $db;
    $query = 'SELECT * FROM depts
              WHERE deptID = :dept_id';
    $statement = $db->prepare($query);
    $statement->bindValue(':dept_id', $dept_id);
    $statement->execute();
    $dept = $statement->fetch();
    $statement->closeCursor();
    return $dept;
}
?>