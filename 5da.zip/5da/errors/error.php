    <main>
        <h1>Unexpected Error</h1>
        <p class="first_paragraph">There was an unexpected error.</p>
        <p>We regret that there was an unexpected error in the program.
            Please try again after correcting the following</p>
        <p class="last_paragraph"> <?php echo $error; ?></p>
    </main>
