<!DOCTYPE html>
<html>
<!-- the head section -->
<head>
    <title>Company</title>
    <link rel="stylesheet" type="text/css" href="/5da/main.css">
    <script src="../validation.js" type="application/javascript"></script>
</head>

<!-- the body section -->
<header><h1 class="shadow">Company</h1>
<div class="HomeDiv"><a class="back" href="/5da/index.php">
        <span class="shadow">Home</span> </a></div>
</header>


</html>