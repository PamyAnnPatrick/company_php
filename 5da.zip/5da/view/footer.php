<footer>
    <p class="copyright">
        &copy; <?php echo date("Y"); ?>  Prog8020: Company
    </p>
</footer>
</body>
</html>