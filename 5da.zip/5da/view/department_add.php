<main>
    <h1>Department add</h1>
    <p class="last_paragraph">
        <a href="index.php?action=list_department">View Department List</a>
    </p>
    <form action="index.php" class="form-background" onsubmit="alertSubmission('Department added successfully')" method="post" id="add_department_form">
        <input type="hidden" name="action" value="add_department">
<table class="subtable">
    <tr>
        <td>
            <label>Department Name:</label>
        </td>
        <td>
            <input type="text" class="inputtxt" onclick="showMessage('Enter all characters for department name')"
                   onblur="removeMessage()"
                    name="dept_name" title="Enter all characters for department name"
                    pattern="[A-Za-z ]+" autofocus required placeholder="Department Name" />
        </td>
    </tr>
    <tr>
        <td colspan="2"> <span id="spanHint" class="hint"></span></td>
    </tr>
     <tr>
         <td colspan="2">
         <input type="submit" value="Add Department" class="button" /></td>
    </tr>

</table>
    </form>

</main>

