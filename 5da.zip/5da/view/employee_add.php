<?php     $departs = get_departments();?>
<main>
        <h1>Add Employee</h1>
    <p class="last_paragraph">
        <a href="index.php?action=list_employee">View Employee List</a>
    </p>
        <form action="index.php" class="form-background" method="post"  onsubmit="alertSubmission('Employee added successfully')"
              id="add_employee_form">
          <table class="subtable">
              <tr>
                  <td>
                      <input type="hidden" name="action" value="add_employee">
                      <label>Department name:</label>
                  </td>
                  <td>
                      <select name="dept_id">
                          <?php foreach ( $departs as $depart ) : ?>
                              <option value="<?php echo $depart['deptID']; ?>">
                                  <?php echo $depart['deptName']; ?>
                              </option>
                          <?php endforeach; ?>
                      </select>
                  </td>
              </tr>
              <tr>
                  <td>
                      <label>Employee Code:</label>
                  </td>
                  <td>
                      <input type="text" class="inputtxt" name="emp_code"
                             onclick="showMessage('Enter all characters for employee code')" onblur="removeMessage()"
                             title="Enter all characters for employee code"
                             pattern="[A-Za-z ]+" autofocus required placeholder="Employee code"/>
                  </td>
              </tr>
              <tr>
                  <td>
                      <label>Employee Name:</label>
                  </td>
                  <td>
                      <input type="text"
                             onclick="showMessage('Enter all characters for employee name')" onblur="removeMessage()"
                             title="Enter all characters for employee name"
                             pattern="[A-Za-z ]+" autofocus required placeholder="Employee name"
                             class="inputtxt" name="emp_name" />
                  </td>
              </tr>
              <tr>
                  <td>
                      <label>Salary:</label>
                  </td>
                  <td>
                      <input type="text"
                             onclick="showMessage('Enter all numeric for salary')" onblur="removeMessage()"
                             title="Enter all numeric for salary"
                             pattern="[0-9.]+" autofocus required placeholder="Salary"
                             class="inputtxt" name="emp_salary" />
                  </td>
              </tr>
              <tr>
                  <td colspan="2"> <span id="spanHint" class="hint"></span></td>
              </tr>
              <tr>
                  <td></td>
                  <td>
                      <input type="submit" class="button" value="Add Employee" />
                  </td>
              </tr>

          </table>
        </form>
    </main>