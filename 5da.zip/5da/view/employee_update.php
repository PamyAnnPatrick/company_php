<?php $departs = get_departments();
$emp_id = filter_input(INPUT_POST, 'employee_id');
$employee = get_employees_id($emp_id);
?>
   <main>
        <h1>Update Employee</h1>
       <p class="last_paragraph">
           <a href="index.php?action=list_employee">View Employee List</a>
       </p>
        <form action="index.php" class="form-background" method="post"
              onsubmit="alertSubmission('Employee updated successfully')"   id="add_employee_form">
            <table class="subtable">
              <tr>
                  <td>
                      <input type="hidden" name="action" value="update_employee">
                      <input type="hidden" name="emp_id" value="<?php echo $employee['empID'];?>">
                      <label>Department name:</label> <br> <br>
                  </td>
                  <td>
                      <select name="dept_id">
                          <?php foreach ( $departs as $depart ) : ?>
                              <?php  if($depart['deptID'] == $employee['deptID']){ ?>
                                  <option value="<?php echo $depart['deptID']; ?>" selected="selected">
                                      <?php echo $depart['deptName']; ?>
                                  </option>
                              <?php }else {?>
                                  <option value="<?php echo $depart['deptID']; ?>">
                                      <?php echo $depart['deptName']; ?>
                                  </option>
                              <?php }?>
                          <?php endforeach; ?>
                      </select>
                  </td>
              </tr>
                <tr>
                    <td>
                        <label>Employee Code:</label>
                    </td>
                    <td>
                        <input type="text" class="inputtxt"
                               onclick="showMessage('Enter all characters for employee code')" onblur="removeMessage()"
                               title="Enter all characters for employee code"
                               pattern="[A-Za-z ]+" autofocus required placeholder="Employee code"
                               value="<?php echo $employee['empCode'];?>" name="emp_code" />
                    </td>
                </tr>
                <tr>
                    <td>
                        <label>Employee Name:</label> <br><br>
                    </td>
                    <td>
                        <input type="text" class="inputtxt"
                               onclick="showMessage('Enter all characters for employee name')" onblur="removeMessage()"
                               title="Enter all characters for employee name"
                               pattern="[A-Za-z ]+" autofocus required placeholder="Employee name"
                               value="<?php echo $employee['empName'];?>" name="emp_name" />
                    </td>
                </tr>
                <tr>
                    <td>
                        <label>Salary:</label>
                    </td>
                    <td>
                        <input type="text"  onclick="showMessage('Enter all numeric for salary')" onblur="removeMessage()"
                               title="nter all numeric for salary"
                               pattern="[0-9.]+" autofocus required placeholder="Salary"
                               class="inputtxt" value="<?php echo $employee['empSalary'];?>" name="emp_salary" />
                    </td>
                </tr>
                <tr>
                    <td colspan="2"> <span id="spanHint" class="hint"></span></td>
                </tr>
                <tr>
                    <td></td>
                    <td>
                        <input type="submit" class="button" value="Update Employee" />
                    </td>
                </tr>

            </table>
        </form>
    </main>