<?php
$dept_id = filter_input(INPUT_POST, 'dept_id');
$department =  get_department($dept_id);
?>
<main>
    <h1>Department update</h1>
    <p class="last_paragraph">
        <a href="index.php?action=list_department">View Department List</a>
    </p>
    <form action="index.php" class="form-background" method="post"  onsubmit="alertSubmission('Department updated successfully')"
          id="update_department_form">
       <table class="subtable">
           <tr>
               <td>
                   <input type="hidden" name="action" value="update_department">
                   <input type="hidden" name="dept_id" value="<?PHP echo $department['deptID']; ?>">
                   <label>Department Name:</label>
               </td>
               <td>
                   <input class="inputtxt" onclick="showMessage('Enter all characters for department name')"
                          onblur="removeMessage()" title="Enter all characters for department name"
                          pattern="[A-Za-z ]+" autofocus required placeholder="Department Name"
                          type="text" value="<?PHP echo $department['deptName']; ?>"  name="dept_name" />
               </td>
           </tr>
           <tr>
               <td colspan="2"> <span id="spanHint" class="hint"></span></td>
           </tr>
           <tr>
               <td></td>
               <td >
                   <input type="submit" class="button" value="Update Department" />
               </td>
           </tr>

       </table>
    </form>

</main>
