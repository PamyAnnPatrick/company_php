<?php
require('../model/database.php');
require('../model/dept_db.php');
include '../view/header.php';
//  setting the value of the Saction variable

$action = filter_input(INPUT_POST, 'action');

// simple validation

if ($action == NULL) {
    $action = filter_input(INPUT_GET, 'action');
    if ($action == NULL) {
        $action = 'list_department';
    }
}
// Default action 'list_department'. It call the function which display list of department
if ($action == 'list_department') {
    DisplayDepartment();
}
else if ($action == 'delete_employee') {
    $dept_id = filter_input(INPUT_POST, 'dept_id', FILTER_VALIDATE_INT);
    if ($dept_id == NULL || $dept_id == FALSE) {
        $error = "Missing or incorrect employee ID";
        include('../errors/error.php');
    } else {
        delete_dept($dept_id);
        header("Location: .?dummy=1");
    }
}
// action to show add new department form
else if ($action == 'show_add_form') {
    include('../view/department_add.php');
}
//action to show edit department form
else if ($action == 'show_update_form') {
    include('../view/department_update.php');
}
// action to insert department to DB
else if ($action == 'add_department') {
    $dept_name = filter_input(INPUT_POST, 'dept_name');

    if ($dept_name == NULL ) {
        $error = "Invalid product data. Check all fields and try again.";
       include('../errors/error.php');
    } else {
        add_department($dept_name);
        DisplayDepartment();
    }
}
//action to update department
else if ($action == 'update_department') {
    $dept_name = filter_input(INPUT_POST, 'dept_name');
    $dept_id = filter_input(INPUT_POST, 'dept_id');
    if ($dept_name == NULL|| $dept_name == $dept_id) {
        $error = "Invalid product data. Check all fields and try again.";
        include('../errors/error.php');
    } else {
        update_department($dept_name,$dept_id);
        DisplayDepartment();
    }
}
// function to display department list
function DisplayDepartment(){
    $departments = get_departments();
    ?>
     <main>
        <h1>Departments List</h1>
        <p class="last_paragraph">
            <a href="?action=show_add_form" title="Add new Department">Add new Department</a>
        </p>
        <section>

            <table class="maintable">
                <tr>
                    <th width="170px">Department ID</th>
                    <th width="200px">Department Name</th>
                    <th width="150px">Delete department</th>
                    <th width="150px">Update department</th>
                </tr>
                <?php foreach ($departments as $department) : ?>
                    <tr>
                        <td><?php echo $department['deptID']; ?></td>
                        <td><?php echo $department['deptName']; ?></td>
                        <td><form action="." method="post">
                                <input type="hidden" name="action" value="delete_employee">
                                <input type="hidden" name="dept_id" value="<?php echo $department['deptID']; ?>">
                                <input type="submit" class="button" value="Delete">
                            </form></td>
                        <td><form action="." method="post">
                                <input type="hidden" name="action" value="show_update_form">
                                <input type="hidden" name="dept_id" value="<?php echo $department['deptID']; ?>">
                                <input type="submit" class="button" value="Update">
                            </form></td>
                    </tr>
                <?php endforeach; ?>
            </table>
            <br>
            <br>
        </section>
    </main>
   <?php
}
include '../view/footer.php';
?>