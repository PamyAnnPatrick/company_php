<?php
require('../model/database.php');
require('../model/dept_db.php');
require('../model/employee_db.php');
include '../view/header.php';
//  setting the value of the Saction variable

$action = filter_input(INPUT_POST, 'action');

// simple validation

if ($action == NULL) {
    $action = filter_input(INPUT_GET, 'action');
    if ($action == NULL) {
        $action = 'list_employee';
    }
}
// Default action 'list_employee'. It call the function which display list of employees

if ($action == 'list_employee') {
    DisplayEmployees();
}
//action to delete employee
else if ($action == 'delete_employee') {
    $employee_id = filter_input(INPUT_POST, 'employee_id', FILTER_VALIDATE_INT);
    if ($employee_id == NULL || $employee_id == FALSE) {
        $error = "Missing or incorrect employee ID";
        include('../errors/error.php');
    } else {
        delete_employee($employee_id);
        header("Location: .?dummy=1");
    }
}
//action to show employee add form
else if ($action == 'show_add_form') {
    include('../view/employee_add.php');
}
//action to show employee edit form
else if ($action == 'show_update_form') {
     include('../view/employee_update.php');
}
//action to save new employee to DB
else if ($action == 'add_employee') {
    $dept_id = filter_input(INPUT_POST, 'dept_id',FILTER_VALIDATE_INT);
    $emp_code = filter_input(INPUT_POST, 'emp_code');
    $emp_name = filter_input(INPUT_POST, 'emp_name');
    $emp_salary = filter_input(INPUT_POST, 'emp_salary', FILTER_VALIDATE_FLOAT);

    if ($dept_id == NULL || $dept_id == FALSE || $emp_code == NULL ||
        $emp_name == NULL || $emp_salary == NULL || $emp_salary == FALSE)
    {
        $error = "Invalid employee details. Check all fields and try again.";
        include('../errors/error.php');
    }
    else
    {
        // call Add employee function
        add_employee($dept_id, $emp_code, $emp_name, $emp_salary);
        DisplayEmployees();
    }
}
//action to save updated details of employee
else if ($action == 'update_employee') {
    $dept_id = filter_input(INPUT_POST, 'dept_id',FILTER_VALIDATE_INT);
    $emp_code = filter_input(INPUT_POST, 'emp_code');
    $emp_id = filter_input(INPUT_POST, 'emp_id');
    $emp_name = filter_input(INPUT_POST, 'emp_name');
    $emp_salary = filter_input(INPUT_POST, 'emp_salary', FILTER_VALIDATE_FLOAT);
    if ($dept_id == NULL || $dept_id == FALSE || $emp_code == NULL ||
        $emp_name == NULL || $emp_salary == NULL || $emp_salary == FALSE)
    {
        $error = "Invalid product data. Check all fields and try again.";
        include('../errors/error.php');
    }
    else
    {
        // call Add employee function
        update_employee($dept_id, $emp_code, $emp_name, $emp_salary,$emp_id);
        DisplayEmployees();
    }
}
//function to display employee list
function DisplayEmployees(){
    $employees = get_employees();
?>

     <main>
        <h1>Employees List</h1>
        <p class="last_paragraph">
            <a href="?action=show_add_form" title="Add Employee">Add Employee</a>
        </p>
        <section>
            <!-- display a table of employee -->
            <table class="maintable">
                <tr>
                    <th width="100px">Employee ID</th>
                    <th width="120px">Employee Code</th>
                    <th width="150px">Employee Name</th>
                    <th width="75px">Employee Salary</th>
                    <th width="150px">Employee Department</th>
                    <th width="150px">Fire an employee</th>
                    <th width="150px">Update employee</th>
                </tr>
                <?php foreach ($employees as $employee) : ?>
                    <tr>
                        <td><?php echo $employee['empID']; ?></td>
                        <td><?php echo $employee['empCode']; ?></td>
                        <td><?php echo $employee['empName']; ?></td>
                        <td class="right"><?php echo $employee['empSalary']; ?></td>
                        <td><?php echo $employee['deptName']; ?></td>
                        <td><form action="." method="post">
                                <input type="hidden" name="action" value="delete_employee">
                                <input type="hidden" name="employee_id" value="<?php echo $employee['empID']; ?>">
                                <input type="submit" width="180px" class="button" value="Fire employee">
                            </form></td>
                        <td><form action="." method="post">
                            <input type="hidden" name="action" value="show_update_form">
                            <input type="hidden" name="employee_id" value="<?php echo $employee['empID']; ?>">
                            <input type="submit" class="button" value="Update">
                        </form></td>
                    </tr>
                <?php endforeach; ?>
            </table>

        </section>
    </main>
    <?php
}
include '../view/footer.php';
?>